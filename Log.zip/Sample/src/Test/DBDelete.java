package Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class DBDelete {

	public static void main(String[] args) {
		 try {
			  
			    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	            String s = "jdbc:sqlserver://192.168.1.56;username=sa;password=sa@sql;DatabaseName=employees;";
			    Connection con = DriverManager.getConnection(s);
			  	Statement st = con.createStatement();
			  	Scanner sc = new Scanner(System.in);
			  	System.out.println("Enter id:");
			  	int a = sc.nextInt();
			  	int rs6 = st.executeUpdate("Delete from employee_details where id="+a+" ");
			  	System.out.println("Deleted");

	         }
		 
		 catch(Exception e){
			 System.out.println(e);
		 }

    }
	
}
