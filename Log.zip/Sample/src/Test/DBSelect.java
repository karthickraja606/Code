package Test;

import java.io.FileInputStream;
import java.sql.*;
import java.util.Properties;
import java.util.Scanner;

public class DBSelect {
	


	public static void main(String[] args) {
		try {
			

			if(!con.isClosed()) {
			System.out.println(getResult(con, id));
			} else {
				System.out.println("Connection Closed....!");
			}







			    Statement st = con.createStatement();
			  	Scanner sc = new Scanner(System.in);
			  	System.out.println("Enter id:");
			  	int a = sc.nextInt();
			  	ResultSet rs6 = st.executeQuery("select * from CONTCTSM1 where OPERATOR_ID='100000000'");
			  	while(rs6.next())  
			  		System.out.println(rs6.getInt(2)); 


		}
		catch(Exception e){
			System.out.println(e);
		}
	}

	public static int getResult(String id) throws SQLException {

		FileInputStream fis = new FileInputStream("Db.properties");
		Properties p = new Properties();
		p.load(fis);

		String driver = p.getProperty("dr");
		String url = p.getProperty("url");
		String username = p.getProperty("username");
		String password = p.getProperty("password");
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,username,password);
	}
	
	
}
	

