package com.test;

import org.apache.log4j.*;

public class Log4 {
	final static  Logger logger = Logger.getLogger(Log4.class);    
	 
	public static void main(String[] args)
	{
	
	Logger rootLogger = Logger.getRootLogger();
	rootLogger.setLevel(Level.DEBUG);
	 
	
	PatternLayout layout = new PatternLayout("%d{ISO8601}  %-5p [%t]  %c %x - %m%n");
	 
	
	rootLogger.addAppender(new ConsoleAppender(layout)); //For Console Print
	
	try{
	FileAppender fileAppender = new FileAppender(layout,"D://logs.log");
	rootLogger.addAppender(fileAppender);
	}
	
	catch(Exception e){
		System.out.println(e);
	}
	
    logger.debug("Debug Level Message!");
    logger.info("Info Level Message!");
    logger.warn("Warn Level Message!");
    logger.error("Error Level Message!");
    logger.fatal("Fatal Level Message!");
	}
	
}

