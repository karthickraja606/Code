package Test;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;


public class JsoArrObj  {
	public static void main(String args[]) throws JSONException{
	
    JSONObject jo = new JSONObject();
	jo.put("firstName", "John");
	jo.put("lastName", "Doe");
	
	JSONObject jo1 = new JSONObject();
	jo1.put("firstName", "Arivu");
	jo1.put("lastName", "Arasu");
	

	JSONArray ja = new JSONArray();
	ja.put(jo);
	ja.put(jo1);
    
	System.out.println(ja);
	
	
    String name = ja.optString(0);

	System.out.println(name);
	
      String scale= ja.getJSONObject(0).getString("lastName");
      System.out.println(scale);
	 
      JSONObject f = ja.getJSONObject(1);
	  String first= f.getString("firstName");
	  System.out.println(first);
	 
}

}