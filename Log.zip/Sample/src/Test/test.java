package Test;

public class test {
	public static void main(String args[]){
		int i=0;
		
		
		while(i<4){
			
			System.out.println("print");
			i++;
			
			
		}
		
		
		
		
	}

}
