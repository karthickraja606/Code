package Test;

public class $conversion {
   public static void main(String args[]){
	   
	   int i = 200;
	   long l = 222222L;
	   float f = 20.2F;
	   double d = 200.333;
	   
	   
	   
	   String s=Integer.toString(i);
	   String s1=Long.toString(l);
	   String s2=Float.toString(f);
	   String s3=Double.toString(d);
	   
	   
	   System.out.println(s+s1+s2+s3);
	   System.out.println(s1);
	   System.out.println(s2);
	   System.out.println(s3);
	   
   }
}
