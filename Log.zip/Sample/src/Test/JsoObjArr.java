package Test;



import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

public class JsoObjArr {

	public static void main(String[] args) throws JSONException {

		JSONArray ja = new JSONArray();  
         ja.put("tamil"); 
		 ja.put(2);
		 ja.put(3.22);
	
		JSONObject jo = new JSONObject();
		  jo.put("ja", ja);
		  //System.out.println(jo);	
		  
		  //String a = jo.getString("ja");
		  
		                  //JSONArray jarr = jo.getJSONArray("ja");
		  
		  String lan = jo.getJSONArray("ja").optString(1);
		  
		  //System.out.println(lan);
		  
		  
		  String js = jo.toString();
		  System.out.println(js);
		  
    }
}
