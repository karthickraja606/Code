package Test;

import java.sql.ResultSet;


public class Conversion {
	public static void main(String args[]){
		String s="200"; 
		String s1 = "20.3";
		
		int i=Integer.parseInt(s);
		long l=Long.parseLong(s);
		float f=Float.parseFloat(s1);
		double d=Double.parseDouble(s1);
	
		System.out.println(i);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
		
		
    }
	
}

