package com;

import java.io.IOException;

import org.apache.log4j.Appender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;


import org.apache.log4j.DailyRollingFileAppender;
  
public class DynamicRollingLogFile {
  
    public static void main(String[] args) throws IOException, InterruptedException {
        // Creates Pattern Layout
        PatternLayout patternLayoutObj = new PatternLayout();
        String conversionPattern = "[%p] %d %c %M - %m%n";
        patternLayoutObj.setConversionPattern(conversionPattern);
  
        // Create Daily Rolling Log File Appender
        DailyRollingFileAppender rollingAppenderObj = new DailyRollingFileAppender();
        rollingAppenderObj.setFile("sample.log");
        rollingAppenderObj.setDatePattern("'.'yyyy-MM");
        rollingAppenderObj.setLayout(patternLayoutObj);
        rollingAppenderObj.activateOptions();
        
        
        RollingFileAppender fAppender = new RollingFileAppender();
        fAppender.setMaxBackupIndex(2);
        fAppender.activateOptions();
        
        //test
//        RollingFileAppender fAppender = new RollingFileAppender(patternLayoutObj, "sample.log", false);
//        fAppender.setMaxFileSize(String.valueOf(10));
//        fAppender.setMaxBackupIndex(2);
//        fAppender.setLayout(patternLayoutObj);
//        fAppender.activateOptions();
        
      
        
        // Configure the Root Logger
        Logger rootLoggerObj = Logger.getRootLogger();
        rootLoggerObj.setLevel(Level.DEBUG);
        rootLoggerObj.addAppender(rollingAppenderObj);
        rootLoggerObj.addAppender(fAppender);
  
        // Create a Customer Logger & Logs Messages
        Logger loggerObj = Logger.getLogger(DynamicRollingLogFile.class);
        for (;;) {
        	  loggerObj.debug("This is a debug log message");
              loggerObj.info("This is an information log message");
              loggerObj.warn("This is a warning log message");
              Thread.sleep(1000);
		}
      
    }
}