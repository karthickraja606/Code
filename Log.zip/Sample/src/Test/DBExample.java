package Test;

import java.sql.*;
import java.util.Scanner;



public class DBExample {
	
	public static void main(String args[]){
		
		 try {
			  
				    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		            String s = "jdbc:sqlserver://192.168.1.57;username=sa;password=Pointel14;DatabaseName=Simple1;";
				    Connection con = DriverManager.getConnection(s);
				  	System.out.println("Connection "+con);
				    //Statement st = con.createStatement();

				  /*
							   Scanner in=new Scanner(System.in); 
							  
						       System.out.println("Enter the Employee ID:");
							   String s1=in.nextLine();
							   System.out.println("Enter the Employee Name:");
							   String s2=in.nextLine();
							   System.out.println("Enter the Employee Age:");
							   String s3=in.nextLine();
							   System.out.println("Enter the Employee position:");
							   String s4=in.nextLine();
							   System.out.println("Enter the Employee Salary:");
							   String s5=in.nextLine();
							   String s6="INSERT INTO employee_details(id,name,age,position,salary) VALUES ('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"') ";
						       st.executeUpdate(s6);
						       
						       
						       System.out.println("Table:");
						       ResultSet rs = st.executeQuery("select * from employee_details");
							  	while(rs.next())  
							  		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"	 "+rs.getString(4)+"	 "+rs.getString(5));
						  	    
							  	 System.out.println("Inserted Successfully");*/
						  	    con.close();
                           
				  	 
				} 
			                   catch (Exception e) { System.out.println(e);
					
				}
	
	     }

}
