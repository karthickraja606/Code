package com;

public class Test {
	
	
	float i = Float.parseFloat("200");
	
	int j = math.round(i);
}
