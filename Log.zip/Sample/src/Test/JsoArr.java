package Test;
import org.json.JSONArray;
import org.json.JSONException;

public class JsoArr {
	
public static void main(String args[]) throws JSONException{    
	 
	  JSONArray arr = new JSONArray();  
	  arr.put("sonoo");    
	  arr.put(new Integer(27));    
	  arr.put(new Double(600000));   
	  System.out.print(arr);  
	  
	  String name = arr.optString(0);
	  int age = arr.optInt(1);
	  double salary = arr.optDouble(2);
	  
	  System.out.println();
	  System.out.println(name);
	  System.out.println(age);
	  System.out.println(salary);
	  
	}

}
