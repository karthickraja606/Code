package com;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;

public class LoggerConfigure {
	
	
	 public static Logger LoggerConfiguration(String filePath, int fileSize, int fileCount, String level, String loggerName, String conversionPattern)
	  {
	    Logger logger = Logger.getLogger(loggerName);
	    logger.removeAllAppenders();
	    Level l = Level.ALL;
	    if ("ALL".equalsIgnoreCase(level)) {
	      l = Level.ALL;
	    } else if ("DEBUG".equalsIgnoreCase(level)) {
	      l = Level.DEBUG;
	    } else if ("INFO".equalsIgnoreCase(level)) {
	      l = Level.INFO;
	    } else if ("WARN".equalsIgnoreCase(level)) {
	      l = Level.WARN;
	    } else if ("ERROR".equalsIgnoreCase(level)) {
	      l = Level.ERROR;
	    }
	    PatternLayout patternlayout = new PatternLayout();
	    patternlayout.setConversionPattern(conversionPattern);
	    try
	    {
	      RollingFileAppender fAppender = new RollingFileAppender();
	      fAppender.setLayout(patternlayout);
	      fAppender.setFile(filePath);
	      fAppender.setAppend(true);
	      fAppender.setMaxFileSize(String.valueOf(fileSize * 1000000));
	      fAppender.setMaxBackupIndex(fileCount);
	      fAppender.activateOptions();
	      logger.addAppender(fAppender);
	      logger.setLevel(l);
	      logger.setAdditivity(false);
	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	    }
	    return logger;
	  }

}
