import java.io.*;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/register")
public class Register extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//response.setContentType("text/html");
		//PrintWriter out = response.getWriter();
		//response.sendRedirect("sucess.html");
		String n=request.getParameter("userName");
		String p=request.getParameter("userPass");
		String e=request.getParameter("userEmail");
	
		System.out.println("working "+n+"  "+p+" "+e);
		try{
		Class.forName("org.mariadb.jdbc.Driver");
		Connection con = DriverManager.getConnection( "jdbc:mariadb://localhost:3306/style", "root", "root");
		PreparedStatement ps=con.prepareStatement("insert into stds values(?,?,?)");
		ps.setString(1,n);
		ps.setString(2,p);
		ps.setString(3,e);
		
		
		
		int i=ps.executeUpdate();
		con.close();
			System.out.println(i +"You are successfully registered...");
		// con.close();
			
		}catch (Exception e2) {
			System.out.println(e2);
			}
		 
		
	}

}
