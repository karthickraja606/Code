package com.test;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;

public class check {

	public static void main(String[] args) {
		
		
		
		StringBuffer tz = new StringBuffer();  
		Calendar c = new GregorianCalendar();
		TimeZone timeZone = c.getTimeZone();
		System.out.println(timeZone.toString());
		
		String[] myName = timeZone.getDisplayName().split(" ");
		for (int i = 0; i < myName.length; i++) {
		        String s = myName[i];
		        tz.append(s.charAt(0));
		}
		System.out.println(tz.toString());
		
		
		  InetAddress addr;
		try {
			addr = InetAddress.getLocalHost();
			String hostname = addr.getHostName();
			System.out.println(hostname);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("error");
		}
		  
		try
        {
            String mcp_IP_str= "123.12.2365@10.11.2.57:12345678;1123.6987.236-987";
            String split_BeforePort=mcp_IP_str.split(";")[0];
           
    	    String split_MCPIPwithPort=split_BeforePort.split("@")[1];
    	   
    	    String mcpIP=split_MCPIPwithPort.substring(0,split_MCPIPwithPort.indexOf(":"));
    	    System.out.println(mcpIP);
        }
    	   
        catch(Exception e)
        { 
        	System.out.println("error");// IvrAppLogger.error("mcpip is empty"+e.toString());
        }
		
		try
		{
		    InetAddress host = InetAddress.getByName("mcpIP");
		   String mcp_hostname=host.getHostName();
		   
		   System.out.println(mcp_hostname);
		}
		catch (UnknownHostException ex)
		{
			System.out.println("error");// IvrAppLogger.error("ExHostname can not be resolved"+ex.toString());
		}
		
		
	
	}

}
