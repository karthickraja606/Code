

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/register")
public class Logincontroller extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String us = request.getParameter("uname");
		String ps = request.getParameter("pass");
		System.out.println("working "+us+"  "+ps);
		if (us.equals("ajay")) {
			Cookie ck=new Cookie("auth",us);
			ck.setMaxAge(1000);
			response.addCookie(ck);
			response.sendRedirect("sucess.jsp");
		}
			else {
				response.sendRedirect("reg.html?status=invalid username or password");
			}
     }
	}

