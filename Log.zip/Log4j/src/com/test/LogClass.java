package com.test;

import org.apache.log4j.*;

public class LogClass {

	   final static Logger logger = Logger.getLogger(LogClass.class);
	   
	   public static void main(String[] args) {
	   PropertyConfigurator.configure("log4j.properties");
		   
	     for(;;){
	      logger.debug("Debug Message!");
	      logger.info("Info Message!");
	      logger.warn("Warn Message!");
	      logger.error("Error Message!");
	      logger.fatal("Fatal Message!");
	     }
	   }
}
