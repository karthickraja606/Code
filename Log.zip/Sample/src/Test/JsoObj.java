package Test;

import org.json.*;
import org.json.JSONObject;

public class JsoObj {

	public static void main(String[] args) throws JSONException  {
		
		
		   
		JSONObject obj=new JSONObject();    
		  obj.put("name","sonoo");    
		  obj.put("age",27);    
		  obj.put("salary",new Double(600000));    
		  System.out.print(obj);
		   
		    String Name = obj.getString("name"); 
	        int age = obj.getInt("age");
	        String salary = obj.getString("salary");
	       
	        System.out.println(Name);
	        System.out.println(age);
	        System.out.println(salary);
	        
	       
	        System.out.println(obj.equals("{}"));
	        System.out.println(obj.has("name"));
	        System.out.println(obj.isNull("name"));
	        
	        
	        
	        String js = stringify(obj);
	        
	}    

}


